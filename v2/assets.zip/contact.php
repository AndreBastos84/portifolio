<?php
declare(strict_types=1);

session_start();

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

function respond(int $statusCode, array $payload): void
{
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function normalizedLength(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
}

function normalizeInlineText($value): string
{
    $value = trim((string) $value);
    $value = str_replace(["\r", "\n", "\t"], ' ', $value);
    $value = preg_replace('/\s+/u', ' ', $value) ?? $value;
    return trim($value);
}

function normalizeMessage($value): string
{
    $value = (string) $value;
    $value = str_replace(["\r\n", "\r"], "\n", $value);
    $value = preg_replace('/\x00/u', '', $value) ?? $value;
    $value = preg_replace("/\n{3,}/", "\n\n", $value) ?? $value;
    return trim($value);
}

function sanitizeHeaderValue(string $value): string
{
    $value = str_replace(["\r", "\n"], ' ', $value);
    $value = preg_replace('/[<>]+/', '', $value) ?? $value;
    $value = preg_replace('/\s+/u', ' ', $value) ?? $value;
    return trim($value);
}

function getCurrentHost(): string
{
    $host = (string) ($_SERVER['HTTP_HOST'] ?? '');
    return preg_replace('/:\d+$/', '', $host) ?? $host;
}

function isSameOriginRequest(): bool
{
    $host = getCurrentHost();
    $origin = (string) ($_SERVER['HTTP_ORIGIN'] ?? '');
    $referer = (string) ($_SERVER['HTTP_REFERER'] ?? '');

    if ($origin !== '') {
        $originHost = parse_url($origin, PHP_URL_HOST);
        return is_string($originHost) && $originHost === $host;
    }

    if ($referer !== '') {
        $refererHost = parse_url($referer, PHP_URL_HOST);
        return is_string($refererHost) && $refererHost === $host;
    }

    return true;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    respond(405, [
        'success' => false,
        'message' => 'Método não permitido.',
    ]);
}

if (!isSameOriginRequest()) {
    respond(403, [
        'success' => false,
        'message' => 'Origem não autorizada.',
    ]);
}

$requestedWith = strtolower((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? ''));

if ($requestedWith !== 'xmlhttprequest') {
    respond(400, [
        'success' => false,
        'message' => 'Solicitação inválida.',
    ]);
}

$contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);

if ($contentLength > 12000) {
    respond(413, [
        'success' => false,
        'message' => 'A mensagem enviada é maior do que o permitido.',
    ]);
}

$honeypot = trim((string) ($_POST['website'] ?? ''));

if ($honeypot !== '') {
    respond(200, [
        'success' => true,
        'message' => 'Mensagem enviada com sucesso.',
    ]);
}

$now = time();
$lastSubmit = (int) ($_SESSION['contact_last_submit'] ?? 0);

if ($lastSubmit > 0 && ($now - $lastSubmit) < 20) {
    respond(429, [
        'success' => false,
        'message' => 'Aguarde alguns segundos antes de enviar uma nova mensagem.',
    ]);
}

$nome = normalizeInlineText($_POST['nome'] ?? '');
$email = strtolower(normalizeInlineText($_POST['email'] ?? ''));
$mensagem = normalizeMessage($_POST['mensagem'] ?? '');

$errors = [];

if ($nome === '') {
    $errors['nome'] = 'Informe seu nome.';
} elseif (normalizedLength($nome) < 2) {
    $errors['nome'] = 'Use pelo menos 2 caracteres.';
} elseif (normalizedLength($nome) > 80) {
    $errors['nome'] = 'Use no máximo 80 caracteres.';
}

if ($email === '') {
    $errors['email'] = 'Informe seu e-mail.';
} elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Digite um e-mail válido.';
} elseif (normalizedLength($email) > 160) {
    $errors['email'] = 'Use no máximo 160 caracteres.';
}

if ($mensagem === '') {
    $errors['mensagem'] = 'Escreva sua mensagem.';
} elseif (normalizedLength($mensagem) < 12) {
    $errors['mensagem'] = 'A mensagem precisa ter pelo menos 12 caracteres.';
} elseif (normalizedLength($mensagem) > 2000) {
    $errors['mensagem'] = 'Use no máximo 2000 caracteres.';
}

if ($errors !== []) {
    respond(422, [
        'success' => false,
        'message' => 'Revise os campos destacados e tente novamente.',
        'errors' => $errors,
    ]);
}

$replyToName = sanitizeHeaderValue($nome);
$replyToEmail = sanitizeHeaderValue($email);
$remoteAddress = sanitizeHeaderValue((string) ($_SERVER['REMOTE_ADDR'] ?? 'não informado'));
$userAgent = sanitizeHeaderValue((string) ($_SERVER['HTTP_USER_AGENT'] ?? 'não informado'));

$subject = 'Novo contato via site';
$body = implode("\n", [
    'Novo contato recebido pelo formulário do site.',
    '',
    'Nome: ' . $nome,
    'E-mail: ' . $email,
    'IP: ' . $remoteAddress,
    'User-Agent: ' . $userAgent,
    'Data: ' . date('d/m/Y H:i:s'),
    '',
    'Mensagem:',
    $mensagem,
]);

$headers = [
    'MIME-Version: 1.0',
    'Content-Type: text/plain; charset=UTF-8',
    'From: ALS Bastos Site <no-reply@alsbastos.com.br>',
    'Reply-To: ' . $replyToName . ' <' . $replyToEmail . '>',
    'X-Mailer: PHP/' . PHP_VERSION,
];

$mailSent = @mail(
    'alsbastos@gmail.com',
    $subject,
    $body,
    implode("\r\n", $headers)
);

if (!$mailSent) {
    respond(500, [
        'success' => false,
        'message' => 'Não foi possível concluir o envio agora. Tente novamente em instantes.',
    ]);
}

$_SESSION['contact_last_submit'] = $now;

respond(200, [
    'success' => true,
    'message' => 'Mensagem enviada com sucesso.',
]);
